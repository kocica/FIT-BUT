Omezení jsem žádná nenalezl, vše vždy fungovalo jak má, pouze
tedy parsování nepovinného loginu u argumentu -l dělá problémy.

Projekt nebyl složitý, tudíž nevím co víc napsat, než to co je
v dokumentaci pdf.