/**
 *		@file 		GUI_Block.hpp
 *		@date 		01/03/2018
 *		@author 	Filip Kocica <xkocic01@fit.vutbr.cz>
 *		@brief 		
 */

#include <iostream>

///
/// Namespace with implementation of GUI of an application
///
namespace BlockEditorGUI
{

}